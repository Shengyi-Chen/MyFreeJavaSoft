package showup.freeware.rdf;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.AbstractMap.SimpleEntry;

import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.TableModel;

public class DefaultSQLTableModel extends AbstractTableModel implements TableModelListener{
		/**
		 * 
		 */
		private static final long serialVersionUID = -3612770277669357062L;
		
		private ArrayList<SimpleEntry<String, Integer>> columnSchema = new ArrayList<SimpleEntry<String, Integer>>();
		private String[] columnHeader = new String[0];
		private Object[][] data =  new Object[0][0];
		
		@Override
		public int getRowCount() {		
			return data.length;
		}

		@Override
		public int getColumnCount() {
			return columnHeader.length;
		}
		
		@Override
		public String getColumnName(int col){
			return columnHeader[col];
		}

		@Override
		public Object getValueAt(int rowIndex, int columnIndex) {
			// TODO Auto-generated method stub
			return data[rowIndex][columnIndex];
		}
		
		@Override
		public void setValueAt(Object value, int row, int col){
			data[row][col] = value;
			fireTableCellUpdated(row, col);
		}

		public Object[][] getData() {
			return data;
		}

		public void setData(String SQLiteDatabaseFile, String SQLiteDataTableName) {
			setColumnHeader(SQLiteDatabaseFile, SQLiteDataTableName);			
			Connection dbConnection = null;
			Statement stmt = null;
		    try {
		      Class.forName("org.sqlite.JDBC");
		      dbConnection = DriverManager.getConnection("jdbc:sqlite:" + SQLiteDatabaseFile);
		      
		      stmt = dbConnection.createStatement();
		      ResultSet rs = stmt.executeQuery( "SELECT * FROM " + SQLiteDataTableName + ";" );		      
		      while (rs.next()) {
		    	  ArrayList<Object> row = new ArrayList<Object>();
		    	  for (int i=0; i<columnSchema.size(); i++){
		    		  String headerID = columnSchema.get(i).getKey();
		    		  int headerType = columnSchema.get(i).getValue();
		    		  switch (headerType){
		    		  case java.sql.Types.ARRAY:
		    			  row.add(rs.getArray(headerID));
		    			  break;
		    		  case java.sql.Types.BIGINT:
		    			  row.add(rs.getBigDecimal(headerID));
		    			  break;
		    		  case java.sql.Types.BINARY:
		    			  row.add(rs.getBytes(headerID));
		    			  break;
		    		  case java.sql.Types.BIT:
		    			  break;
		    		  case java.sql.Types.BLOB:
		    			  break;
		    		  case java.sql.Types.BOOLEAN:
		    			  row.add(rs.getBoolean(headerID));
		    			  break;
		    		  case java.sql.Types.CHAR:
		    			  row.add(rs.getString(headerID));
		    			  break;
		    		  case java.sql.Types.CLOB:
		    			  break;
		    		  case java.sql.Types.DATALINK:
		    			  break;
		    		  case java.sql.Types.DATE:
		    			  row.add(rs.getDate(headerID));
		    			  break;
		    		  case java.sql.Types.DECIMAL:
		    			  row.add(rs.getInt(headerID));
		    			  break;
		    		  case java.sql.Types.DISTINCT:
		    			  break;
		    		  case java.sql.Types.DOUBLE:
		    			  row.add(rs.getDouble(headerID));
		    			  break;
		    		  case java.sql.Types.FLOAT:
		    			  row.add(rs.getFloat(headerID));
		    			  break;
		    		  case java.sql.Types.INTEGER:
		    			  row.add(rs.getInt(headerID));
		    			  break;
		    		  case java.sql.Types.JAVA_OBJECT:
		    			  row.add(rs.getObject(headerID));
		    			  break;
		    		  case java.sql.Types.LONGNVARCHAR:
		    			  break;
		    		  case java.sql.Types.LONGVARBINARY:
		    			  break;
		    		  case java.sql.Types.LONGVARCHAR:
		    			  break;
		    		  case java.sql.Types.NCHAR:
		    			  break;
		    		  case java.sql.Types.NCLOB:
		    			  break;
		    		  case java.sql.Types.NULL:
		    			  row.add(null);
		    			  break;
		    		  case java.sql.Types.NUMERIC:
		    			  break;
		    		  case java.sql.Types.NVARCHAR:
		    			  break;
		    		  case java.sql.Types.OTHER:
		    			  break;
		    		  case java.sql.Types.REAL:
		    			  break;
		    		  case java.sql.Types.REF:
		    			  break;
		    		  case java.sql.Types.REF_CURSOR:
		    			  break;
		    		  case java.sql.Types.ROWID:
		    			  break;
		    		  case java.sql.Types.SMALLINT:
		    			  break;
		    		  case java.sql.Types.SQLXML:
		    			  break;
		    		  case java.sql.Types.STRUCT:
		    			  break;
		    		  case java.sql.Types.TIME:
		    			  break;
		    		  case java.sql.Types.TIME_WITH_TIMEZONE:
		    			  break;
		    		  case java.sql.Types.TIMESTAMP:
		    			  break;
		    		  case java.sql.Types.TIMESTAMP_WITH_TIMEZONE:
		    			  break;
		    		  case java.sql.Types.TINYINT:
		    			  break;
		    		  case java.sql.Types.VARBINARY:
		    			  break;
		    		  case java.sql.Types.VARCHAR:
		    			  row.add(rs.getString(headerID));
		    			  break;
		    		  default:
		    			  break;		    		  
		    		  }
		    	  }

		    	  Object[][] newData = new Object[this.data.length + 1][row.size()];
		    	  System.arraycopy(row.toArray(), 0, newData[this.data.length], 0, row.size());		    	  
		    	  System.arraycopy(this.data, 0, newData, 0, this.data.length);		    	  
		    	  this.data = newData;
		    	  row.clear();
		      }

		      stmt.close();
		      dbConnection.close();
		    } catch ( Exception e ) {
		      System.err.println( e.getClass().getName() + ": " + e.getMessage() );
		    }
		    
		}

		public String[] getColumnHeader() {
			return columnHeader;
		}

		private void setColumnHeader(String SQLiteDatabaseFile, String SQLiteDataTableName) {
			List<String> columnHeader = new ArrayList<String>();
			Connection dbConnection = null;
		    try {
		      Class.forName("org.sqlite.JDBC");
		      dbConnection = DriverManager.getConnection("jdbc:sqlite:" + SQLiteDatabaseFile);		      
		      ResultSet allColumns = dbConnection.getMetaData().getColumns(null, null, SQLiteDataTableName, null);
		      while (allColumns.next()){	    	  
		    	  columnHeader.add(allColumns.getString(4));
		    	  this.columnSchema.add(new SimpleEntry<String, Integer>(allColumns.getString(4), 
		    			  Integer.parseInt(allColumns.getString(5))));	    	  
		      }
		      dbConnection.close();
		    } catch ( Exception e ) {
		      System.err.println( e.getClass().getName() + ": " + e.getMessage() );
		    }
			this.columnHeader = columnHeader.toArray(this.columnHeader);
		}

		@Override
		public void tableChanged(TableModelEvent e) {
			int row = e.getFirstRow();
			int column = e.getColumn();
			TableModel model = (TableModel) e.getSource();
			String columnName = model.getColumnName(column);
			Object data = model.getValueAt(row, column);
			
		}
}
