package showup.freeware.rdf;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class DefaultSettings {
	
	private static final byte algorithmMD5 =  32;
	private static final byte algorithmSHA =  16;
	private static final byte algorithmNA =   48;
	
	private static final byte methodFull = 12;
	private static final byte methodFast = 8;
	
	private static final byte actionDelete = 3;
	private static final byte actionMove = 2;
	private static final byte actionAsk = 1;
	private static final byte actionNothing = 0;

	private static final byte algorithmMASK = 0b110000;	
	private static final byte methodMASK = 0b1100;	
	private static final byte actionMASK = 0b11;
	
	private boolean isAlgMD5;
	private boolean isAlgSHA;
	private boolean isAlgNA;
	
	private boolean isMethodFull;
	private boolean isMethodFast;
	
	private boolean isActionDelete;
	private boolean isActionMove;
	private boolean isActionAsk;
	private boolean isActionNothing;
	
	private final File cfgFile = new File("showupRDF.cfg");	
	/*
	 * actionDelete
	 * methodFast
	 * algorithmMD5
	 * 
	 * */
	private byte defaultValue = 0;
	
	public DefaultSettings(){			
		if (!cfgFile.exists()){			
			setAlgMD5();
			setMethodFast();
			setActionDelete();			
			SaveSettings();
		}
	}

	public void LoadSettings(){
		FileInputStream in = null;
	    try {
	    	in = new FileInputStream(cfgFile);
	    	defaultValue = (byte) in.read();
	    	
	    	
	    } catch (IOException i) {
	      i.printStackTrace();
	    } finally {
	      try {
	        if (in != null) {
	        	in.close();
	        }
	      } catch (IOException e) {
	      }
	    }
	}
	
	public void SaveSettings(){
		FileOutputStream out = null;
		try {
			out = new FileOutputStream(cfgFile);
			out.write(defaultValue);
			out.close();
		}catch (IOException ioe) {
			
		} finally{
			try {
		        if (out != null) {
		        	out.close();
		        }
		      } catch (IOException e) {
		      }
		}
	}
	
	public boolean isAlgMD5() {		
		return (defaultValue & algorithmMASK) == algorithmMD5;	
	}

	public void setAlgMD5() {		
		this.isAlgSHA = false;
		this.isAlgNA = false;
		
		defaultValue = (byte) (defaultValue + algorithmMD5);
		this.isAlgMD5 = true;
	}

	public boolean isAlgSHA() {		
		return (defaultValue & algorithmMASK) == algorithmSHA;
	}

	public void setAlgSHA() {
		this.isAlgMD5 = false;
		this.isAlgNA = false;
		
		defaultValue = (byte) (defaultValue + algorithmSHA);		
		this.isAlgSHA = true;
	}

	public boolean isAlgNA() {
		return (defaultValue & algorithmMASK) == algorithmNA;
	}

	public void setAlgNA() {	
		this.isAlgMD5 = false;
		this.isAlgSHA = false;
		
		defaultValue = (byte) (defaultValue + algorithmNA);		
		this.isAlgNA = true;
	}

	public boolean isMethodFull() {
		return (defaultValue & methodMASK) == methodFull;
	}

	public void setMethodFull() {
		this.isMethodFast = false;
		defaultValue = (byte) (defaultValue + methodFull);
		this.isMethodFull = true;
	}

	public boolean isMethodFast() {
		return (defaultValue & methodMASK) == methodFast;
	}

	public void setMethodFast() {
		this.isMethodFull = false;
		defaultValue = (byte) (defaultValue + methodFast);
		this.isMethodFast = true;
	}

	public boolean isActionDelete() {
		return (defaultValue & actionMASK) == actionDelete;
	}

	public void setActionDelete() {
		this.isActionAsk = false;
		this.isActionMove = false;
		this.isActionNothing = false;
		this.isActionDelete = false;
		defaultValue = (byte) (defaultValue + actionDelete);
		
		this.isActionDelete = true;
	}

	public boolean isActionMove() {
		return (defaultValue & actionMASK) == actionMove;
	}

	public void setActionMove() {
		this.isActionAsk = false;
		this.isActionMove = false;
		this.isActionNothing = false;
		this.isActionDelete = false;
		defaultValue = (byte) (defaultValue + actionMove);
		
		this.isActionMove = true;
	}

	public boolean isActionAsk() {
		return (defaultValue & actionMASK) == actionAsk;
	}

	public void setActionAsk() {
		this.isActionAsk = false;
		this.isActionMove = false;
		this.isActionNothing = false;
		this.isActionDelete = false;
		defaultValue = (byte) (defaultValue + actionAsk);
		
		this.isActionAsk = true;
	}

	public boolean isActionNothing() {
		return (defaultValue & actionMASK) == actionNothing;
	}

	public void setActionNothing() {
		this.isActionAsk = false;
		this.isActionMove = false;
		this.isActionNothing = false;
		this.isActionDelete = false;
		defaultValue = (byte) (defaultValue + actionNothing);
		
		this.isActionNothing = true;
	}	
	
}
