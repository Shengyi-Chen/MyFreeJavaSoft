package showup.freeware.rdf;

public class DefaultSettings {

}
