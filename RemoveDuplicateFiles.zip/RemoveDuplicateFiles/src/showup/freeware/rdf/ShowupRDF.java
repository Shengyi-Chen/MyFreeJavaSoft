package showup.freeware.rdf;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JToolBar;

import java.awt.BorderLayout;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JToggleButton;
import javax.swing.JSeparator;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.JScrollPane;
import javax.swing.JPanel;

import java.awt.FlowLayout;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.border.MatteBorder;

import java.awt.Color;

import javax.swing.border.BevelBorder;
import javax.swing.SwingConstants;

import java.util.ResourceBundle;

import javax.swing.JRadioButton;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JTextPane;

public class ShowupRDF {
	private static final ResourceBundle BUNDLE = ResourceBundle.getBundle("showup.freeware.rdf.messages"); //$NON-NLS-1$

	private JFrame frame;
	private JPanel panelEast = null;
	private JPanel panelWest = null;
	private JToggleButton tglbtnSettings = null;
	private JToggleButton tglbtnInfo = null;
	private JRadioButton rdbtnNone = null;
	private JRadioButton rdbtnFastCheckjust = null;
	private JRadioButton rdbtnFullCheck = null;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ShowupRDF window = new ShowupRDF();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public ShowupRDF() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 616, 508);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JToolBar toolBar = new JToolBar();
		frame.getContentPane().add(toolBar, BorderLayout.NORTH);
		
		JButton btnOpen = new JButton("");
		btnOpen.setIcon(new ImageIcon(ShowupRDF.class.getResource("/showup/freeware/icons/Very_Basic/folder-48.png")));
		toolBar.add(btnOpen);
		
		JSeparator separator = new JSeparator();
		toolBar.add(separator);	
		
		tglbtnSettings = new JToggleButton("");
		tglbtnSettings.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (null != panelEast) {
					
					if (((JToggleButton) e.getSource()).isSelected()){
						//TODO: Load settings
						panelEast.setVisible(true);
					}else{
						//TODO: Save settings
						panelEast.setVisible(false);
						
					}
					
				}	
			}
		});
		
		
		tglbtnInfo = new JToggleButton("\r\n");
		tglbtnInfo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (null != panelWest){
					panelWest.setVisible(((JToggleButton) e.getSource()).isSelected());
				}
				
			}
		});
		tglbtnInfo.setIcon(new ImageIcon(ShowupRDF.class.getResource("/showup/freeware/icons/Very_Basic/about-48.png")));
		toolBar.add(tglbtnInfo);
		tglbtnSettings.setIcon(new ImageIcon(ShowupRDF.class.getResource("/showup/freeware/icons/Very_Basic/support-48.png")));
		toolBar.add(tglbtnSettings);
		
		JSeparator separator_1 = new JSeparator();
		toolBar.add(separator_1);
		
		JButton btnClose = new JButton("");
		btnClose.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
			}
		});
		btnClose.setIcon(new ImageIcon(ShowupRDF.class.getResource("/showup/freeware/icons/Household/door-48.png")));
		toolBar.add(btnClose);
		
		panelEast = new JPanel();
		panelEast.setBorder(new MatteBorder(0, 2, 0, 0, (Color) new Color(255, 240, 245)));
		panelEast.setVisible(false);
		frame.getContentPane().add(panelEast, BorderLayout.EAST);
		
		JLabel lblFile = new JLabel("");
		lblFile.setLabelFor(panelEast);
		lblFile.setHorizontalAlignment(SwingConstants.RIGHT);
		lblFile.setBackground(new Color(255, 240, 245));
		lblFile.setOpaque(true);
		lblFile.setIcon(new ImageIcon(ShowupRDF.class.getResource("/showup/freeware/icons/Very_Basic/services-48.png")));
		
		JLabel lblChecksumMethod = new JLabel(BUNDLE.getString("checksum_method_label")); //$NON-NLS-1$
		
		JRadioButton rdbtnMd = new JRadioButton(BUNDLE.getString("ShowupRDF.rdbtnMd.text")); //$NON-NLS-1$
		rdbtnMd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {				
					rdbtnFastCheckjust.setEnabled(rdbtnMd.isSelected());
					rdbtnFullCheck.setEnabled(rdbtnMd.isSelected());
			}
		});
		
		JRadioButton rdbtnSha = new JRadioButton(BUNDLE.getString("ShowupRDF.rdbtnSha.text")); //$NON-NLS-1$
		rdbtnSha.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
					rdbtnFastCheckjust.setEnabled(rdbtnSha.isSelected());
					rdbtnFullCheck.setEnabled(rdbtnSha.isSelected());
			}
		});
		
		rdbtnNone = new JRadioButton(BUNDLE.getString("ShowupRDF.rdbtnNone.text")); //$NON-NLS-1$
		rdbtnNone.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (null != rdbtnNone){
					rdbtnFastCheckjust.setEnabled(!rdbtnNone.isSelected());
					rdbtnFullCheck.setEnabled(!rdbtnNone.isSelected());
				}
			}
		});
		
		ButtonGroup chkMethodBg = new ButtonGroup();
		chkMethodBg.add(rdbtnMd);
		chkMethodBg.add(rdbtnSha);
		chkMethodBg.add(rdbtnNone);
		
		JLabel lblCheckingMethod = new JLabel(BUNDLE.getString("ShowupRDF.lblCheckingMethod.text")); //$NON-NLS-1$
		
		rdbtnFastCheckjust = new JRadioButton(BUNDLE.getString("ShowupRDF.rdbtnFastCheckjust.text"));
		rdbtnFullCheck = new JRadioButton(BUNDLE.getString("ShowupRDF.rdbtnFullCheck.text")); //$NON-NLS-1$
		
		ButtonGroup chkMethodMd = new ButtonGroup();
		chkMethodMd.add(rdbtnFastCheckjust);
		chkMethodMd.add(rdbtnFullCheck);		
		
		JLabel lblDefaultAction = new JLabel(BUNDLE.getString("ShowupRDF.lblDefaultAction.text")); //$NON-NLS-1$
		
		JRadioButton rdbtnDeleteDuplicateFile = new JRadioButton(BUNDLE.getString("ShowupRDF.rdbtnDeleteDuplicateFile.text")); //$NON-NLS-1$
		JRadioButton rdbtnAskMeWhat = new JRadioButton(BUNDLE.getString("ShowupRDF.rdbtnAskMeWhat.text")); //$NON-NLS-1$
		JRadioButton rdbtnCopyDuplicateFile = new JRadioButton(BUNDLE.getString("ShowupRDF.rdbtnCopyDuplicateFile.text")); //$NON-NLS-1$
		JRadioButton rdbtnDoNothing = new JRadioButton(BUNDLE.getString("ShowupRDF.rdbtnDoNothing.text")); //$NON-NLS-1$
		
		ButtonGroup dABg = new ButtonGroup();
		dABg.add(rdbtnDeleteDuplicateFile);
		dABg.add(rdbtnAskMeWhat);
		dABg.add(rdbtnCopyDuplicateFile);
		dABg.add(rdbtnDoNothing);
		
		GroupLayout gl_panelEast = new GroupLayout(panelEast);
		gl_panelEast.setHorizontalGroup(
			gl_panelEast.createParallelGroup(Alignment.TRAILING)
				.addGroup(gl_panelEast.createSequentialGroup()
					.addGroup(gl_panelEast.createParallelGroup(Alignment.TRAILING)
						.addComponent(lblFile, GroupLayout.DEFAULT_SIZE, 249, Short.MAX_VALUE)
						.addGroup(gl_panelEast.createSequentialGroup()
							.addContainerGap()
							.addGroup(gl_panelEast.createParallelGroup(Alignment.LEADING)
								.addComponent(lblChecksumMethod)
								.addGroup(gl_panelEast.createSequentialGroup()
									.addComponent(rdbtnMd)
									.addPreferredGap(ComponentPlacement.UNRELATED)
									.addComponent(rdbtnSha)
									.addPreferredGap(ComponentPlacement.UNRELATED)
									.addComponent(rdbtnNone))
								.addComponent(lblCheckingMethod))
							.addGap(15)))
					.addGap(12))
				.addGroup(Alignment.LEADING, gl_panelEast.createSequentialGroup()
					.addContainerGap()
					.addComponent(lblDefaultAction)
					.addContainerGap(170, Short.MAX_VALUE))
				.addGroup(Alignment.LEADING, gl_panelEast.createSequentialGroup()
					.addContainerGap()
					.addComponent(rdbtnDeleteDuplicateFile)
					.addContainerGap(117, Short.MAX_VALUE))
				.addGroup(Alignment.LEADING, gl_panelEast.createSequentialGroup()
					.addContainerGap()
					.addComponent(rdbtnCopyDuplicateFile, GroupLayout.DEFAULT_SIZE, 237, Short.MAX_VALUE)
					.addGap(16))
				.addGroup(Alignment.LEADING, gl_panelEast.createSequentialGroup()
					.addContainerGap()
					.addComponent(rdbtnAskMeWhat)
					.addContainerGap(123, Short.MAX_VALUE))
				.addGroup(Alignment.LEADING, gl_panelEast.createSequentialGroup()
					.addContainerGap()
					.addComponent(rdbtnDoNothing)
					.addContainerGap(168, Short.MAX_VALUE))
				.addGroup(Alignment.LEADING, gl_panelEast.createSequentialGroup()
					.addContainerGap()
					.addComponent(rdbtnFullCheck)
					.addContainerGap(171, Short.MAX_VALUE))
				.addGroup(Alignment.LEADING, gl_panelEast.createSequentialGroup()
					.addContainerGap()
					.addComponent(rdbtnFastCheckjust)
					.addContainerGap(16, Short.MAX_VALUE))
		);
		gl_panelEast.setVerticalGroup(
			gl_panelEast.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panelEast.createSequentialGroup()
					.addComponent(lblFile, GroupLayout.PREFERRED_SIZE, 53, GroupLayout.PREFERRED_SIZE)
					.addGap(18)
					.addComponent(lblChecksumMethod)
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addGroup(gl_panelEast.createParallelGroup(Alignment.BASELINE)
						.addComponent(rdbtnMd)
						.addComponent(rdbtnSha)
						.addComponent(rdbtnNone))
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addComponent(lblCheckingMethod)
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addComponent(rdbtnFastCheckjust)
					.addGap(4)
					.addComponent(rdbtnFullCheck)
					.addGap(8)
					.addComponent(lblDefaultAction)
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addComponent(rdbtnDeleteDuplicateFile)
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addComponent(rdbtnCopyDuplicateFile)
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addComponent(rdbtnAskMeWhat)
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addComponent(rdbtnDoNothing)
					.addContainerGap(40, Short.MAX_VALUE))
		);
		panelEast.setLayout(gl_panelEast);
		
		panelWest = new JPanel();
		panelWest.setBorder(new MatteBorder(0, 0, 0, 2, (Color) new Color(240, 248, 255)));
		panelWest.setVisible(false);
		frame.getContentPane().add(panelWest, BorderLayout.WEST);
		
		JLabel lblInfomation = new JLabel("");
		lblInfomation.setHorizontalAlignment(SwingConstants.LEFT);
		lblInfomation.setOpaque(true);
		lblInfomation.setForeground(Color.BLACK);
		lblInfomation.setBackground(new Color(240, 248, 255));
		lblInfomation.setIcon(new ImageIcon(ShowupRDF.class.getResource("/showup/freeware/icons/Very_Basic/checkmark-48.png")));
		
		JLabel lblFileName = new JLabel(BUNDLE.getString("ShowupRDF.lblFileName.text")); //$NON-NLS-1$
		
		JTextPane textPane = new JTextPane();
		textPane.setText("");
		GroupLayout gl_panelWest = new GroupLayout(panelWest);
		gl_panelWest.setHorizontalGroup(
			gl_panelWest.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panelWest.createSequentialGroup()
					.addContainerGap()
					.addComponent(lblFileName)
					.addContainerGap())
				.addGroup(gl_panelWest.createSequentialGroup()
					.addGap(5)
					.addComponent(lblInfomation, GroupLayout.DEFAULT_SIZE, 205, Short.MAX_VALUE))
				.addGroup(gl_panelWest.createSequentialGroup()
					.addContainerGap()
					.addComponent(textPane, GroupLayout.DEFAULT_SIZE, 246, Short.MAX_VALUE)
					.addContainerGap())
		);
		gl_panelWest.setVerticalGroup(
			gl_panelWest.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panelWest.createSequentialGroup()
					.addComponent(lblInfomation, GroupLayout.PREFERRED_SIZE, 53, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(lblFileName)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(textPane, GroupLayout.PREFERRED_SIZE, 81, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(239, Short.MAX_VALUE))
		);
		panelWest.setLayout(gl_panelWest);
	}
}
