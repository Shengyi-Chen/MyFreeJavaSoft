package showup.freeware.rdf;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JToolBar;

import java.awt.BorderLayout;

import javax.swing.ButtonGroup;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JToggleButton;
import javax.swing.JSeparator;

import java.awt.event.ActionListener;
import java.io.File;
import java.awt.event.ActionEvent;

import javax.swing.JScrollPane;
import javax.swing.JPanel;

import java.awt.FlowLayout;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.border.MatteBorder;

import java.awt.Color;

import javax.swing.border.BevelBorder;
import javax.swing.SwingConstants;

import java.util.ArrayList;
import java.util.ResourceBundle;

import javax.swing.JRadioButton;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.ListModel;
import javax.swing.JTextPane;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JProgressBar;
import javax.swing.JCheckBox;
import javax.swing.JEditorPane;
import javax.swing.JTextArea;

public class ShowupRDF {
	private static final ResourceBundle BUNDLE = ResourceBundle.getBundle("showup.freeware.rdf.messages"); //$NON-NLS-1$

	private JFrame frame;
	private JPanel panelEast = null;
	private JPanel panelWest = null;
	private JToggleButton tglbtnSettings = null;
	private JToggleButton tglbtnInfo = null;
	
	private JRadioButton rdbtnMd = null;
	private JRadioButton rdbtnSha = null;
	private JRadioButton rdbtnNone = null;	
	
	private JRadioButton rdbtnFastCheckjust = null;
	private JRadioButton rdbtnFullCheck = null;
	
	private JRadioButton rdbtnDeleteDuplicateFile = null;
	private JRadioButton rdbtnAskMeWhat = null;
	private JRadioButton rdbtnCopyDuplicateFile = null;
	private JRadioButton rdbtnDoNothing = null;
	
	private DefaultListModel<File> folderList = new DefaultListModel<File>();
	private JList list = null;
	
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ShowupRDF window = new ShowupRDF();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public ShowupRDF() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 1169, 652);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JToolBar toolBar = new JToolBar();
		frame.getContentPane().add(toolBar, BorderLayout.NORTH);
		
		
		tglbtnInfo = new JToggleButton("\r\n");
		tglbtnInfo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (null != panelWest){
					panelWest.setVisible(((JToggleButton) e.getSource()).isSelected());
				}
				
			}
		});
		tglbtnInfo.setIcon(new ImageIcon(ShowupRDF.class.getResource("/showup/freeware/icons/Very_Basic/checkmark-48.png")));
		toolBar.add(tglbtnInfo);
		
		JSeparator separator = new JSeparator();
		toolBar.add(separator);
		
		tglbtnSettings = new JToggleButton("");
		tglbtnSettings.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (null != panelEast) {
					
					if (((JToggleButton) e.getSource()).isSelected()){
						//TODO: Load settings
						DefaultSettings defStg = new DefaultSettings();
						defStg.LoadSettings();
						
						rdbtnMd.setSelected(defStg.isAlgMD5());
						rdbtnSha.setSelected(defStg.isAlgSHA());
						rdbtnNone.setSelected(defStg.isAlgNA());						
						
						rdbtnFastCheckjust.setSelected(defStg.isMethodFast());
						rdbtnFullCheck.setSelected(defStg.isMethodFull());
						
						rdbtnDeleteDuplicateFile.setSelected(defStg.isActionDelete());
						rdbtnAskMeWhat.setSelected(defStg.isActionAsk());
						rdbtnCopyDuplicateFile.setSelected(defStg.isActionMove());
						rdbtnDoNothing.setSelected(defStg.isActionNothing());
						
						panelEast.setVisible(true);
					}else{
						//TODO: Save settings
						DefaultSettings defStgSav = new DefaultSettings();						
						if (rdbtnMd.isSelected()){
							defStgSav.setAlgMD5();
						}
						if (rdbtnSha.isSelected()){
							defStgSav.setAlgSHA();
						}
						if (rdbtnNone.isSelected()){
							defStgSav.setAlgNA();
						}

						if (rdbtnFastCheckjust.isSelected()){
							defStgSav.setMethodFast();
						}
						if (rdbtnFullCheck.isSelected()){
							defStgSav.setMethodFull();
						}
						
						if (rdbtnDeleteDuplicateFile.isSelected()){
							defStgSav.setActionDelete();
						}
						if (rdbtnAskMeWhat.isSelected()){
							defStgSav.setActionAsk();
						}
						if (rdbtnCopyDuplicateFile.isSelected()){
							defStgSav.setActionMove();
						}
						if (rdbtnDoNothing.isSelected()){
							defStgSav.setActionNothing();
						}
						
						defStgSav.SaveSettings();
						panelEast.setVisible(false);
						
					}
					
				}	
			}
		});
		tglbtnSettings.setIcon(new ImageIcon(ShowupRDF.class.getResource("/showup/freeware/icons/Very_Basic/services-48.png")));
		toolBar.add(tglbtnSettings);
		
		panelEast = new JPanel();
		panelEast.setBorder(new MatteBorder(0, 2, 0, 0, (Color) new Color(255, 240, 245)));
		panelEast.setVisible(false);
		frame.getContentPane().add(panelEast, BorderLayout.EAST);
		
		JLabel lblFile = new JLabel("");
		lblFile.setLabelFor(panelEast);
		lblFile.setHorizontalAlignment(SwingConstants.RIGHT);
		lblFile.setBackground(new Color(255, 240, 245));
		lblFile.setOpaque(true);
		lblFile.setIcon(new ImageIcon(ShowupRDF.class.getResource("/showup/freeware/icons/Very_Basic/services-48.png")));
		
		JLabel lblChecksumMethod = new JLabel(BUNDLE.getString("checksum_method_label")); //$NON-NLS-1$
		
		rdbtnMd = new JRadioButton(BUNDLE.getString("ShowupRDF.rdbtnMd.text")); //$NON-NLS-1$
		rdbtnMd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {				
					rdbtnFastCheckjust.setEnabled(rdbtnMd.isSelected());
					rdbtnFullCheck.setEnabled(rdbtnMd.isSelected());
			}
		});
		
		rdbtnSha = new JRadioButton(BUNDLE.getString("ShowupRDF.rdbtnSha.text")); //$NON-NLS-1$
		rdbtnSha.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
					rdbtnFastCheckjust.setEnabled(rdbtnSha.isSelected());
					rdbtnFullCheck.setEnabled(rdbtnSha.isSelected());
			}
		});
		
		rdbtnNone = new JRadioButton(BUNDLE.getString("ShowupRDF.rdbtnNone.text")); //$NON-NLS-1$
		rdbtnNone.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (null != rdbtnNone){
					rdbtnFastCheckjust.setEnabled(!rdbtnNone.isSelected());
					rdbtnFullCheck.setEnabled(!rdbtnNone.isSelected());
				}
			}
		});
		
		ButtonGroup chkMethodBg = new ButtonGroup();
		chkMethodBg.add(rdbtnMd);
		chkMethodBg.add(rdbtnSha);
		chkMethodBg.add(rdbtnNone);		
		
		JLabel lblCheckingMethod = new JLabel(BUNDLE.getString("ShowupRDF.lblCheckingMethod.text")); //$NON-NLS-1$
		
		rdbtnFastCheckjust = new JRadioButton(BUNDLE.getString("ShowupRDF.rdbtnFastCheckjust.text"));
		rdbtnFullCheck = new JRadioButton(BUNDLE.getString("ShowupRDF.rdbtnFullCheck.text")); //$NON-NLS-1$
		
		ButtonGroup chkMethodMd = new ButtonGroup();
		chkMethodMd.add(rdbtnFastCheckjust);
		chkMethodMd.add(rdbtnFullCheck);		
		
		JLabel lblDefaultAction = new JLabel(BUNDLE.getString("ShowupRDF.lblDefaultAction.text")); //$NON-NLS-1$
		
		rdbtnDeleteDuplicateFile = new JRadioButton(BUNDLE.getString("ShowupRDF.rdbtnDeleteDuplicateFile.text")); //$NON-NLS-1$
		rdbtnAskMeWhat = new JRadioButton(BUNDLE.getString("ShowupRDF.rdbtnAskMeWhat.text")); //$NON-NLS-1$
		rdbtnCopyDuplicateFile = new JRadioButton(BUNDLE.getString("ShowupRDF.rdbtnCopyDuplicateFile.text")); //$NON-NLS-1$
		rdbtnDoNothing = new JRadioButton(BUNDLE.getString("ShowupRDF.rdbtnDoNothing.text")); //$NON-NLS-1$
		
		ButtonGroup dABg = new ButtonGroup();
		dABg.add(rdbtnDeleteDuplicateFile);
		dABg.add(rdbtnAskMeWhat);
		dABg.add(rdbtnCopyDuplicateFile);
		dABg.add(rdbtnDoNothing);
		
		GroupLayout gl_panelEast = new GroupLayout(panelEast);
		gl_panelEast.setHorizontalGroup(
			gl_panelEast.createParallelGroup(Alignment.TRAILING)
				.addGroup(gl_panelEast.createSequentialGroup()
					.addGroup(gl_panelEast.createParallelGroup(Alignment.TRAILING)
						.addComponent(lblFile, GroupLayout.DEFAULT_SIZE, 249, Short.MAX_VALUE)
						.addGroup(gl_panelEast.createSequentialGroup()
							.addContainerGap()
							.addGroup(gl_panelEast.createParallelGroup(Alignment.LEADING)
								.addComponent(lblChecksumMethod)
								.addGroup(gl_panelEast.createSequentialGroup()
									.addComponent(rdbtnMd)
									.addPreferredGap(ComponentPlacement.UNRELATED)
									.addComponent(rdbtnSha)
									.addPreferredGap(ComponentPlacement.UNRELATED)
									.addComponent(rdbtnNone))
								.addComponent(lblCheckingMethod))
							.addGap(15)))
					.addGap(12))
				.addGroup(Alignment.LEADING, gl_panelEast.createSequentialGroup()
					.addContainerGap()
					.addComponent(lblDefaultAction)
					.addContainerGap(170, Short.MAX_VALUE))
				.addGroup(Alignment.LEADING, gl_panelEast.createSequentialGroup()
					.addContainerGap()
					.addComponent(rdbtnDeleteDuplicateFile)
					.addContainerGap(117, Short.MAX_VALUE))
				.addGroup(Alignment.LEADING, gl_panelEast.createSequentialGroup()
					.addContainerGap()
					.addComponent(rdbtnCopyDuplicateFile, GroupLayout.DEFAULT_SIZE, 237, Short.MAX_VALUE)
					.addGap(16))
				.addGroup(Alignment.LEADING, gl_panelEast.createSequentialGroup()
					.addContainerGap()
					.addComponent(rdbtnAskMeWhat)
					.addContainerGap(123, Short.MAX_VALUE))
				.addGroup(Alignment.LEADING, gl_panelEast.createSequentialGroup()
					.addContainerGap()
					.addComponent(rdbtnDoNothing)
					.addContainerGap(168, Short.MAX_VALUE))
				.addGroup(Alignment.LEADING, gl_panelEast.createSequentialGroup()
					.addContainerGap()
					.addComponent(rdbtnFullCheck)
					.addContainerGap(171, Short.MAX_VALUE))
				.addGroup(Alignment.LEADING, gl_panelEast.createSequentialGroup()
					.addContainerGap()
					.addComponent(rdbtnFastCheckjust)
					.addContainerGap(16, Short.MAX_VALUE))
		);
		gl_panelEast.setVerticalGroup(
			gl_panelEast.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panelEast.createSequentialGroup()
					.addComponent(lblFile, GroupLayout.PREFERRED_SIZE, 53, GroupLayout.PREFERRED_SIZE)
					.addGap(18)
					.addComponent(lblChecksumMethod)
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addGroup(gl_panelEast.createParallelGroup(Alignment.BASELINE)
						.addComponent(rdbtnMd)
						.addComponent(rdbtnSha)
						.addComponent(rdbtnNone))
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addComponent(lblCheckingMethod)
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addComponent(rdbtnFastCheckjust)
					.addGap(4)
					.addComponent(rdbtnFullCheck)
					.addGap(8)
					.addComponent(lblDefaultAction)
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addComponent(rdbtnDeleteDuplicateFile)
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addComponent(rdbtnCopyDuplicateFile)
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addComponent(rdbtnAskMeWhat)
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addComponent(rdbtnDoNothing)
					.addContainerGap(40, Short.MAX_VALUE))
		);
		panelEast.setLayout(gl_panelEast);
		
		panelWest = new JPanel();
		panelWest.setBorder(new MatteBorder(0, 0, 0, 2, (Color) new Color(240, 248, 255)));
		panelWest.setVisible(false);
		frame.getContentPane().add(panelWest, BorderLayout.WEST);
		
		JLabel lblInfomation = new JLabel("");
		lblInfomation.setHorizontalAlignment(SwingConstants.LEFT);
		lblInfomation.setOpaque(true);
		lblInfomation.setForeground(Color.BLACK);
		lblInfomation.setBackground(new Color(240, 248, 255));
		lblInfomation.setIcon(new ImageIcon(ShowupRDF.class.getResource("/showup/freeware/icons/Very_Basic/checkmark-48.png")));
		
		JLabel lblFileName = new JLabel(BUNDLE.getString("ShowupRDF.lblFileName.text"));
		
		JScrollPane scrollPane = new JScrollPane();
		
		JButton btnAdd = new JButton(BUNDLE.getString("ShowupRDF.btnAdd.text")); //$NON-NLS-1$
		btnAdd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JFileChooser fc = new JFileChooser();
				fc.setDialogTitle(BUNDLE.getString("ShowupRDF.fc.dialogtitle"));
				fc.setAcceptAllFileFilterUsed(true);
				fc.setMultiSelectionEnabled(true);
				fc.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
				int resVal = fc.showOpenDialog(frame);
				if(resVal ==  JFileChooser.APPROVE_OPTION){					
					for (File selectedFile : fc.getSelectedFiles()){
						folderList.add(0, selectedFile);
					}
				}
			}
		});
		
		JButton btnDelete = new JButton(BUNDLE.getString("ShowupRDF.btnDelete.text")); //$NON-NLS-1$
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					folderList.remove(list.getSelectedIndex());					
				}
				catch (java.lang.ArrayIndexOutOfBoundsException arrayE){
					JOptionPane.showMessageDialog(frame, BUNDLE.getString("ShowupRDF.joptionpane.errorOutOfArrayMsg"), 
							BUNDLE.getString("ShowupRDF.joptionpane.errorOutOfArrayTitle"), JOptionPane.ERROR_MESSAGE);
				}
			}
		});
		
		JCheckBox chckbxIgnoreFilesAnd = new JCheckBox(BUNDLE.getString("ShowupRDF.chckbxIgnoreFilesAnd.text")); //$NON-NLS-1$
		
		JCheckBox chckbxNameFilter = new JCheckBox(BUNDLE.getString("ShowupRDF.chckbxNameFilter.text"));
		
		JScrollPane scrollPane_1 = new JScrollPane();
		GroupLayout gl_panelWest = new GroupLayout(panelWest);
		gl_panelWest.setHorizontalGroup(
			gl_panelWest.createParallelGroup(Alignment.TRAILING)
				.addGroup(gl_panelWest.createSequentialGroup()
					.addContainerGap()
					.addComponent(lblFileName)
					.addContainerGap())
				.addGroup(gl_panelWest.createSequentialGroup()
					.addGap(5)
					.addComponent(lblInfomation, GroupLayout.DEFAULT_SIZE, 319, Short.MAX_VALUE))
				.addGroup(gl_panelWest.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_panelWest.createParallelGroup(Alignment.TRAILING)
						.addGroup(gl_panelWest.createSequentialGroup()
							.addComponent(btnAdd)
							.addPreferredGap(ComponentPlacement.RELATED, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
							.addComponent(btnDelete))
						.addComponent(scrollPane, GroupLayout.DEFAULT_SIZE, 291, Short.MAX_VALUE))
					.addGap(21))
				.addGroup(gl_panelWest.createSequentialGroup()
					.addContainerGap()
					.addComponent(chckbxNameFilter)
					.addContainerGap(225, Short.MAX_VALUE))
				.addGroup(Alignment.LEADING, gl_panelWest.createSequentialGroup()
					.addContainerGap()
					.addComponent(scrollPane_1, GroupLayout.DEFAULT_SIZE, 290, Short.MAX_VALUE)
					.addGap(22))
				.addGroup(Alignment.LEADING, gl_panelWest.createSequentialGroup()
					.addContainerGap()
					.addComponent(chckbxIgnoreFilesAnd, GroupLayout.DEFAULT_SIZE, 304, Short.MAX_VALUE)
					.addGap(12))
		);
		gl_panelWest.setVerticalGroup(
			gl_panelWest.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panelWest.createSequentialGroup()
					.addComponent(lblInfomation, GroupLayout.PREFERRED_SIZE, 53, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(lblFileName)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(scrollPane, GroupLayout.DEFAULT_SIZE, 129, Short.MAX_VALUE)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addGroup(gl_panelWest.createParallelGroup(Alignment.BASELINE)
						.addComponent(btnAdd)
						.addComponent(btnDelete))
					.addGap(18)
					.addComponent(chckbxIgnoreFilesAnd)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(chckbxNameFilter)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(scrollPane_1, GroupLayout.DEFAULT_SIZE, 210, Short.MAX_VALUE)
					.addGap(11))
		);
		
		JTextArea textArea = new JTextArea();
		textArea.setText("");
		scrollPane_1.setViewportView(textArea);
		
		list = new JList();
		list.setModel(folderList);
		scrollPane.setViewportView(list);
		panelWest.setLayout(gl_panelWest);
		
		JProgressBar progressBar = new JProgressBar();
		frame.getContentPane().add(progressBar, BorderLayout.SOUTH);
		
		JScrollPane scrollPane_2 = new JScrollPane();
		frame.getContentPane().add(scrollPane_2, BorderLayout.CENTER);
		
		JTextArea textArea_1 = new JTextArea();
		textArea_1.setText("");
		scrollPane_2.setViewportView(textArea_1);
	}
}
