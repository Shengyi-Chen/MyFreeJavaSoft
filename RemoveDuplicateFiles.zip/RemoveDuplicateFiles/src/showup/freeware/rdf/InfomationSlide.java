package showup.freeware.rdf;

import javax.swing.JComponent;
import java.awt.Color;
import javax.swing.JLabel;

public class InfomationSlide extends JComponent {
	public InfomationSlide() {
		setForeground(Color.PINK);
		setBackground(Color.RED);
		
		JLabel lblThisIsA = new JLabel("This is a info test");
		lblThisIsA.setBounds(12, 13, 122, 274);
		add(lblThisIsA);
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 7799780374926455378L;
}
