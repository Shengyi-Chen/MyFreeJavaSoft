package showup.freeware.rdf;

public class DatabaseFunc {

}
