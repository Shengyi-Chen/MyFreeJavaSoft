package showup.freeware.rdf;

import java.sql.Connection;
import java.sql.DriverManager;

public class DatabaseFunc {
	private Connection c = null;
	
	public DatabaseFunc(){		
		try {
			Class.forName("org.sqlite.JDBC");
			c = DriverManager.getConnection("jdbc:sqlite:showupDB");
		} catch ( Exception e ) {
			System.err.println( e.getClass().getName() + ": " + e.getMessage() );
		}
	}
	
	
}

