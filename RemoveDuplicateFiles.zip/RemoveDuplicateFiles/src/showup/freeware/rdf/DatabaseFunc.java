package showup.freeware.rdf;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.attribute.BasicFileAttributes;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class DatabaseFunc {
	
	private Connection conn = null;
	private Statement stmt = null;
	private int ID = 0;
	
	public DatabaseFunc(){		
		File dbFile = new File("showupDB");
		if (dbFile.exists()){
			dbFile.delete();
		}
		/*
		 * Table Structure FILELIST
		 * ID
		 * FILE
		 * SIZE
		 * CHECKSUM
		 * CREATE DATE
		 * LAST MODIFY
		 * */
		
		try {
			Class.forName("org.sqlite.JDBC");
			conn = DriverManager.getConnection("jdbc:sqlite:showupDB");
			
			stmt = conn.createStatement();
		    stmt.executeUpdate(
		    				"CREATE TABLE FILELIST " +
		    				"(ID INT PRIMARY KEY     NOT NULL," +
		    				" NAME           TEXT    NOT NULL, " + 
		    				" SIZE            LONG     NOT NULL, " + 
		    				" CHECKSUM        TEXT, " + 
		    				" CREATE_DATE	TEXT	NOT NULL," +
	                   		"LAST_MODIFY	TEXT	NOT NULL)");
		    
		    conn.close();
		    stmt.close();
		} catch ( Exception e ) {
			System.err.println( e.getClass().getName() + ": " + e.getMessage());
		}
	}
	
	public void add(File file, String checksum){
		ID++;
		
		try{
			BasicFileAttributes fAttr = Files.readAttributes(file.toPath(), BasicFileAttributes.class);
			conn = DriverManager.getConnection("jdbc:sqlite:showupDB");			
			stmt = conn.createStatement();
			stmt.executeUpdate("INSERT INTO FILELIST (ID, NAME, SIZE, CHECKSUM, CREATE_DATE, LAST_MODIFY)"
					+ "VALUES (" + ID + ", '"
								+ file.getName() + "', '"
								+ file.length() + "', '"
								+ checksum +"', '"
								+ fAttr.creationTime().toString() + "', '"
								+ fAttr.lastModifiedTime().toString()
								+ "');");
			//conn.commit();
			
			stmt.close();
			conn.close();
		}catch (Exception e){
			System.err.println( e.getClass().getName() + ": " + e.getMessage());
		}
	}
	
	public void delete(int ID){
		
	}
	
	
}

