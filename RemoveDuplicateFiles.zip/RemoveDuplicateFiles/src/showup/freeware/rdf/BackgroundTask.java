package showup.freeware.rdf;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;

import javax.swing.SwingWorker;

public class BackgroundTask<T, V> extends SwingWorker<T, V> {
	private ArrayList<File> foldersList;
	private boolean isSystemProtectedSkipped = true;
	private String[] fileFilter;
	private DefaultSettings cfg;
	
	public BackgroundTask(){
		cfg = new DefaultSettings();
		cfg.LoadSettings();
	}
	
	private static String convertByteArrayToHexString(byte[] arrayBytes) {
        StringBuffer stringBuffer = new StringBuffer();
        for (int i = 0; i < arrayBytes.length; i++) {
            stringBuffer.append(Integer.toString((arrayBytes[i] & 0xff) + 0x100, 16)
                    .substring(1));
        }
        return stringBuffer.toString();
    }
	
	private String doHash(File file, String algorithm, boolean isFast){
		FileInputStream inputStream = null;
		try {
			inputStream = new FileInputStream(file);
			MessageDigest digest = MessageDigest.getInstance(algorithm);		    
			 
	        byte[] bytesBuffer = new byte[1024];
	        int bytesRead = -1;
	        if (isFast){
	        	bytesRead = inputStream.read(bytesBuffer);
	        	digest.update(bytesBuffer, 0, bytesRead);
	        }else{
	        	  while ((bytesRead = inputStream.read(bytesBuffer)) != -1) {
	  	            digest.update(bytesBuffer, 0, bytesRead);
	  	        }
	        }	      
	 
	        byte[] hashedBytes = digest.digest();
	        inputStream.close();
	        return convertByteArrayToHexString(hashedBytes);
		} catch (IOException | NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			if (null != inputStream){
				try {
					inputStream.close();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} finally{
					try {
						inputStream.close();
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
			}
			return "";
		}
	}

	private String doCheck(File inFile){
		String result = "";
		if (cfg.isAlgNA()){
			//TODO:			
			result = Long.toString(inFile.length());
		}else {
			if (cfg.isAlgMD5()) {
				if (cfg.isMethodFull())
					result =  doHash(inFile, "MD5", false);
				if (cfg.isMethodFast())
					result =  doHash(inFile, "MD5", true);	
			}
			
			if (cfg.isAlgSHA()){
				if (cfg.isMethodFull())
					result = doHash(inFile, "SHA-256", false);
				if (cfg.isMethodFast())
					result = doHash(inFile, "SHA-256", true);
				
			}
			
		}
		
		return result;
	}
	private void ListFiles(File pathFolder){
		if (pathFolder.isDirectory()){
			for (File inF : pathFolder.listFiles()){
				if (inF.isDirectory()){
					ListFiles(inF);
				}else{
					//TODO: do check					
					System.out.println(inF.getName() + " <-> " + doCheck(inF));
				}
			}
		}else{
			//TODO: do check
			System.out.println(pathFolder.getName() + ": " + doCheck(pathFolder));
		}
			
	}
	@Override
	protected T doInBackground() throws Exception {
		// TODO Auto-generated method stub
		for (File eachFolder : foldersList){
			ListFiles(eachFolder);
		}
		return null;
	}
	
	@Override
	protected void done(){
		
	}

	public ArrayList<File> getFoldersList() {
		return foldersList;
	}

	public void setFoldersList(ArrayList<File> foldersList) {
		this.foldersList = foldersList;
	}

	public boolean isSystemProtectedSkipped() {
		return isSystemProtectedSkipped;
	}

	public void setSystemProtectedSkipped(boolean isSystemProtectedSkipped) {
		this.isSystemProtectedSkipped = isSystemProtectedSkipped;
	}

	public String[] getFileFilter() {
		return fileFilter;
	}

	public void setFileFilter(String[] fileFilter) {
		this.fileFilter = fileFilter;
	}

	
}
